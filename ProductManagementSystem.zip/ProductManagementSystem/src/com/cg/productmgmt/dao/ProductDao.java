package com.cg.productmgmt.dao;

import java.util.HashMap;
import java.util.*;

import com.cg.productmgmt.exception.ProductException;

public class ProductDao implements IProductDao {
	static Map<String, String> productDetails;
	static Map<String, Integer> salesDetails;
	static Map<String, Integer> salesDetails1= new HashMap<>();
	static
	{ productDetails=new HashMap<>();
	  productDetails.put("lux", "soap");
	  productDetails.put("colgate", "paste");
	  productDetails.put("pears", "soap");
	  productDetails.put("sony", "electronics");
	  productDetails.put("samsung", "electronics");
	  productDetails.put("facepack", "cosmetics");
	  productDetails.put("facecream", "cosmetics");
	  
	  salesDetails=new HashMap<>();
	  salesDetails.put("lux", 100);
	  salesDetails.put("colgate", 50);
	  salesDetails.put("pears", 70);
	  salesDetails.put("sony", 10000);
	  salesDetails.put("samsung", 23000);
	  salesDetails.put("facepack", 100);
	  salesDetails.put("facecream",60);	
		
	}

	@Override
	public int updateProducts(String category, int hike) 
			throws ProductException 
	{
		Set<String> s=productDetails.keySet(); 
		Iterator<String> it=s.iterator();
		//Set<String> productName=new HashSet<String >();
		int flag=0;
		//System.out.println("dao1");
		while(it.hasNext())
		{
			//System.out.println("dao*");
			String productkey=it.next();
			if(category.equals(productDetails.get(productkey)))
			{
				//System.out.println("dao2");
				//productName.add(key);
      			Set<String> s1=salesDetails.keySet(); 
				Iterator<String> it1=s1.iterator();
				while(it1.hasNext())
				{
					String saleskey=it1.next();
					if(productkey.equals(saleskey))
					{
						//System.out.println("dao3");
						int price=salesDetails.get(saleskey);
						int newPrice=(int) (price+price*(hike/100.0));
						salesDetails1.put(saleskey, newPrice);
					flag=1;
					}
				}
				
			}
		}
		return flag;
	}

	@Override
	public Map<String, Integer> getProductDetails() 
			throws ProductException 
	{
		return salesDetails1;
	}


	

}
