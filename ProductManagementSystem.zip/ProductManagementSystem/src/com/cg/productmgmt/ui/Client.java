package com.cg.productmgmt.ui;

import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.cg.productmgmt.exception.ProductException;
import com.cg.productmgmt.service.ProductService;

public class Client {
	static ProductService pSer=new ProductService();
	static Scanner sc= new Scanner(System.in);
	public static void main(String[] args) {
		
		while(true) {
		System.out.println("1.Update Product Price");
		System.out.println("2.Exit");
		int choice;
		System.out.println("Enter your choice:");
		
		choice=sc.nextInt();
		switch(choice) {
		
		case 1:
			updateProd();
			break;
			
		case 2:
			System.out.println("Application Closed");
			System.exit(0);
			break;
		}
		}
	}

	private static void updateProd() {
		System.out.println("Enter  category: ");
		String cat=sc.next();
		System.out.println("Enter hike: ");
		int hk=sc.nextInt();
		try {
			pSer.updateProducts(cat, hk);
			Map<String,Integer> productDetails=pSer.getProductDetails();
			Set<String> key=productDetails.keySet();
			Iterator<String> it= key.iterator();
			while(it.hasNext())
			{
				String key1=it.next();
				System.out.println("ProductName: "+key1+"Price: "+productDetails.get(key1));
			}
			
			System.out.println("Sucessfully updated\n");
		} catch (ProductException e) {
		
			e.printStackTrace();
		}
		
	}

}
