package com.cg.productmgmt.service;

import java.util.Map;

import com.cg.productmgmt.dao.ProductDao;
import com.cg.productmgmt.exception.ProductException;

public class ProductService implements IProductService{
	ProductDao pDao=new ProductDao();

	@Override
	public int updateProducts(String category, int hike) throws ProductException {
		return pDao.updateProducts(category, hike);
	}

	@Override
	public Map<String, Integer> getProductDetails() throws ProductException {
		return pDao.getProductDetails();
	}

}
